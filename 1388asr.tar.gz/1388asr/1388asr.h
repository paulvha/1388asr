/* supports display on 1388 ASR
 *  8 x 8 led display
 *
 * version 1.0 / paulvha / April 2016
 ****************************************************************************
 * The following characters are supported:
 *  0 - 9 (numbers)
 *  a - z
 *  A - Z
 *  special characters / signs :
 *        space
 *      - minus
 *      _ underscore
 *      ~ tilde
 *      ( [ { opening brackets
 *      ) ] } closing brackets
 *      < less than
 *      > greater than
 *      ^ to the power off
 *      \ backward slash
 *      / forward slash
 *      @ degree symbol
 *      ' quote
 *      " quotation
 *      = equal
 *      ! exclamation mark
 *      $ dollar
 *      & ampersand
 *      # hash
 *      . dot
 *      , comma
 *      * asterisk
 *      : colon
 *      ; semicolon
 *      ? question mark
 *      + plus
 *      % percent
 *
 ****************************************************************************
 *
 * HARDWARE SETUP :
 *
 * display      40-pin      GPIO    description
 * ---------------------------------------------
 * 1            37          26       row5
 * 2            35          19       row7
 * 3            33          13          col2
 * 4            31          6           col3
 * 5            29          5        row8
 * 6            15          22          col5
 * 7            13          27       row6
 * 8            11          17       row3
 * 9            12          18       row1
 * 10           16          23          col4
 * 11           18          24          col6
 * 12           22          25       row4
 * 13           32          12          col1
 * 14           36          16       row2
 * 15           38          20          col7
 * 16           40          21          col8
 ****************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 *
 * This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 *
 */

/* use wiringPi as alternative to BCM2835
 * this is normally provided with -D_wiring with gcc
 * see:  build_led file.
 */
//#define _wiring

// color display
#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

// to be used as parameters in the calls
#define CLR     0
#define APPEND  1
#define START   2
#define NEW     3
#define CTRLC   4
#define SET     5

// move direction
#define LEFT    1
#define UP      2
#define DOWN    3

// attribute
#define BLINK   0x01
#define UNDER   0x02

#define MLEFT   0x10
#define MUP     0x20
#define MDOWN   0x40

/* indicates that source data is being updated with critical timing
 * refresh_disp will return immediately without refresh
 * should not take more than 10ms */
int capture_busy;

/* MUST be called first to setup the GPIO
 * parameter 1 (CTRLC)= will setup for control-c handling */
void do_init(int set);

/* Display message,
 * parameter disp: START = start message, CLR = end message */
void e_message(int disp);

/* clears the message buffer, optional clear the display buffer as well */
void clr_buffer(int clr);

/* sets a character
 * instr:
 * APPEND = add to current buffer
 * START = add at beginning
 * NEW = clear current buffer
 * In case of NEW all existing attributes are cleared */
int set_char (int instr, char val);

/* adds value to string (max 20 characters)
 * instr:
 * APPEND = add to current buffer
 * START = add at beginning
 * NEW = clear current buffer  */
int set_value (int instr, int num);

/* sets to display a buffer
 * instr:
 * APPEND = add to current buffer
 * START = add at beginning
 * NEW = clear current buffer  */
int set_string(int instr, char buf[]);

/* set underscore ON or OFF
 * set parameter:  on = 1 (SET), off = 0 (CLR) */
void set_underscore(int set);

/* set refresh rate in milliseconds.
 * Can be value between 5 and 25. Default is 10.
 * Brightness level will be maximum 500 at refresh 5.
 * Refresh time is max 8 x dis_bright.
 * With brightlevel:                min refresh time
 * 2000 microseconds x 8 = 16ms     < 17ms refresh
 * 1300 microseconds x 8 = 10,1ms   <15ms refresh
 * 1150 microseconds x 8 = 9ms =>   10ms refresh
 * 1000 microseconds x 8 = 8ms =>   9ms.
 * 900 microseconds x 8 = 7,2ms =>  8ms.
 * 800 microseconds x 8 = 6,4ms =>  7ms.
 * 650 microseconds x 8 = 5.2ms =>  6ms.
 * 500 microseconds x 8 = 4ms =>    5ms.
 * The brightlevel is adjusted down if necessary depening on the
 * refresh rate.
 *
 * return 0 = OK, 1 = invalid value (ignored) */
int set_refresh(int refresh);

/* set move speed
 * max is 60 (300 ms)
 * min is 5 ( 25 ms))  */
int set_move_sp(int speed);

/* set the direction from THIS point in the buffer
 * to either LEFT, UP or DOWN */
int set_move_dir(int direct);

/* set the brightness (on-time of leds).
 * value can be between 5 and 2000 Usec
 * Default is 1150.
 * Refresh_rate  brightness MAX
 * 5             500
 * 6             650
 * 7             800
 * 8             900
 * 9             1000
 * 10            1150
 * 10 <> 15      1300
 * 16            1800
 *
 * return 0 = OK, 1 = invalid value */
int set_brightness(int bright);

/* repeat message in buffer
 * SET = keep repeating
 * CLR = do NOT repeat (default)
 * the buffer can continue to be updated !! */
void set_repeat(int set);

/* set blinking a character(s)
 * parameter:  set on = 1 (SET), off = 0 (CLR) */
void set_blink(int set);

/* blinking speed
 * if speed = CLR : default speed of 200
 * else value between 50 or 300
 * return 1 if invalid speed value */
int set_blink_speed(int speed);

/* must be called to close the GPIO's' correctly
 * parameter = 1 (SET): display exit message */
void do_exit(int flsh);

/* will perform a test on a display :
 * single moving dot
 * single moving column
 * single moving row
 * cross/star
 * numeric characters
 * upper case characters
 * lower case characters
 * special characters */
int do_selftest();

/* as sleep() function seems to collite with setitimer()
 * psleep can be used to count down
 * value * 5ms = sleeptime */
void psleep(long value);

/* getch(), gets a single character at a time without a return nor display.
 * returns read character if successful.
 * returns -1 on non-fatal error.
 * returns -2 on fatal error. */
char get_ch();

/* will read character from keyboard handling itimer interrupts */
char get_char();

/* will read a line from the keyboard in a buffer handling itimer
 * interrupts
 * buf = buffert to store line
 * max = maximum characters to read
 * will return the length of the characters in buffer
 * buffer will be terminated with \0.
 * Either when enter was pressed or max was reached. */
int get_line(char buf[], int max);

/* wait for the last characters to be displayed
 * if opt =1 the program will exit as well */
void wait_exit(int opt);

/*********** supporting routines ************/
/**** not mend for user level usages ********/

/* will refresh display of the display. The refresh time can
 * be set with set_refresh. Default 10ms (100hz)
 * will call disp_update_left, down or up depending on attribute*/
void refresh_disp(void);

/* move columns left and add space between characters */
void disp_update_left();

/* move rows down and add space between characters */
void disp_update_down();

/* move rows up and add space between characters */
void disp_update_up();

/* set info in current display array on display
 * called from disp_update_left, down or up */
void to_disp();

/* signal handler in case control-c was requested with do-init() */
void signal_handler(int sig_num);


