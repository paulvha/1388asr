/*
 * supports display on 1388ASR
 *
 * version 1.0 / paulvha / april 2016
 *
 * see 1388asr.h for details
 *
 * ***************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 *
 * This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 *
 ***************************************************************************
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include "timer.h"
#include "1388asr.h"
#include <time.h>
#include <termios.h>
#include <unistd.h>

#ifdef _wiring
#include <wiringPi.h>
#else
#include "bcm2835.h"
#endif

// display debugg messages
int debugg = 0;

// current display
int cur_dsp[8][8]={0,0};

// the disp_char and disp_char_r_c MUST align !
char disp_char[96]={
    '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
    'p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I',
    'J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
    '/','\\','(',')','{','}','[',']',' ','<','>','=','~','!','?','-','+','^','%','&','_',
    '@','\'','"','*',':',';','$','@','#','.',',','|',0};

// MUST ALIGN TO disp_char[]
int disp_char_r_c [95][6][5] =
{   //------HIGHEST--------------------col------------------LOWEST-------------
    {{0,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // O
    {{0,1,1,0,0},{1,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,1,1,1,0}},   // 1
    {{0,1,1,1,0},{1,0,0,0,1},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0},{1,1,1,1,1}},   // 2
    {{0,1,1,1,0},{1,0,0,0,1},{0,0,0,1,0},{0,0,1,1,0},{0,0,0,0,1},{1,1,1,1,0}},   // 3
    {{0,0,1,1,0},{0,1,0,1,0},{1,0,0,1,0},{1,1,1,1,1},{0,0,0,1,0},{0,0,0,1,0}},   // 4
    {{1,1,1,1,1},{1,0,0,0,0},{1,1,1,1,1},{0,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // 5
    {{0,1,1,1,1},{1,0,0,0,0},{1,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // 6
    {{1,1,1,1,1},{0,0,0,0,1},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0},{1,0,0,0,0}},   // 7
    {{0,1,1,1,0},{1,0,0,0,1},{0,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // 8
    {{0,1,1,1,0},{1,0,0,0,1},{0,1,1,1,1},{0,0,0,0,1},{0,0,0,0,1},{1,1,1,1,0}},   // 9
    {{0,0,0,0,0},{1,1,1,1,0},{0,0,0,0,1},{0,1,1,1,1},{1,0,0,0,1},{0,1,1,1,1}},   // a
    {{0,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,1,1,1,0},{1,0,0,0,1},{1,1,1,1,0}},   // b
    {{0,0,0,0,0},{0,1,1,1,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,1},{0,1,1,1,0}},   // c
    {{0,0,0,0,0},{0,0,0,0,1},{0,0,0,0,1},{0,1,1,1,1},{1,0,0,0,1},{0,1,1,1,1}},   // d
    {{0,0,0,0,0},{0,1,1,1,0},{1,0,0,0,1},{1,1,1,1,1},{1,0,0,0,0},{0,1,1,1,1}},   // e
    {{0,0,0,0,0},{0,1,1,1,1},{0,1,0,0,0},{1,1,1,1,0},{0,1,0,0,0},{0,1,0,0,0}},   // f
    {{0,0,0,0,0},{0,1,1,1,0},{1,0,0,0,1},{1,1,1,1,1},{0,0,0,0,1},{1,1,1,1,0}},   // g
    {{0,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0},{1,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1}},   // h
    {{0,0,0,0,0},{0,0,1,0,0},{0,0,0,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0}},   // i
    {{0,0,0,0,0},{0,0,1,0,0},{0,0,0,0,0},{0,0,1,0,0},{1,0,1,0,0},{0,1,1,0,0}},   // j
    {{0,0,0,0,0},{1,0,0,0,0},{1,0,0,1,0},{1,1,1,0,0},{1,0,1,0,0},{1,0,0,1,0}},   // k
    {{0,0,0,0,0},{0,1,0,0,0},{0,1,0,0,0},{0,1,0,0,0},{0,1,0,0,1},{0,0,1,1,0}},   // l
    {{0,0,0,0,0},{1,1,0,1,1},{1,0,1,0,1},{1,0,1,0,1},{1,0,1,0,1},{1,0,1,0,1}},   // m
    {{0,0,0,0,0},{0,0,0,0,0},{1,0,0,0,0},{1,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1}},   // n
    {{0,0,0,0,0},{0,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // o
    {{0,0,0,0,0},{1,1,1,1,0},{1,0,0,0,1},{1,1,1,1,0},{1,0,0,0,0},{1,0,0,0,0}},   // p
    {{0,0,0,0,0},{0,1,1,1,1},{1,0,0,0,1},{0,1,1,1,1},{0,0,0,0,1},{0,0,0,0,1}},   // q
    {{0,0,0,0,0},{0,1,0,0,0},{0,1,1,1,0},{0,1,0,1,0},{0,1,0,0,0},{0,1,0,0,0}},   // r
    {{0,0,0,0,0},{0,1,1,1,1},{1,0,0,0,0},{0,1,1,1,0},{0,0,0,0,1},{1,1,1,1,0}},   // s
    {{0,0,0,0,0},{0,1,0,0,0},{0,1,0,0,0},{1,1,1,1,0},{0,1,0,0,0},{0,0,1,1,0}},   // t
    {{0,0,0,0,0},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,1}},   // u
    {{0,0,0,0,0},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,0,1,0},{0,0,1,0,0}},   // v
    {{0,0,0,0,0},{1,0,0,0,1},{1,0,1,0,1},{1,0,1,0,1},{0,1,1,1,0},{0,1,0,1,0}},   // w
    {{0,0,0,0,0},{1,0,0,0,1},{0,1,0,1,0},{0,0,1,0,0},{0,1,0,1,0},{1,0,0,0,1}},   // x
    {{0,0,0,0,0},{1,0,0,0,1},{0,1,0,1,0},{0,0,1,0,0},{0,0,1,0,0},{0,1,1,0,0}},   // y
    {{0,0,0,0,0},{1,1,1,1,1},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0},{1,1,1,1,1}},   // z
    {{1,1,1,1,1},{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,1},{1,0,0,0,1},{1,0,0,0,1}},   // A
    {{1,1,1,1,0},{1,0,0,0,1},{1,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,0}},   // B
    {{0,1,1,1,0},{1,0,0,0,1},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,1},{0,1,1,1,0}},   // C
    {{1,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,0}},   // D
    {{0,1,1,1,1},{1,0,0,0,0},{1,1,1,1,1},{1,0,0,0,0},{1,0,0,0,0},{0,1,1,1,1}},   // E
    {{0,1,1,1,1},{1,0,0,0,0},{1,1,1,1,0},{1,0,0,0,0},{1,0,0,0,0},{1,0,0,0,0}},   // F
    {{0,1,1,1,1},{1,0,0,0,0},{1,0,1,1,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // G
    {{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1}},   // H
    {{0,1,1,1,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,1,1,1,0}},   // I
    {{0,1,1,1,0},{0,0,0,1,0},{0,0,0,1,0},{0,0,0,1,0},{1,0,0,1,0},{0,1,1,1,0}},   // J
    {{1,0,0,0,0},{1,0,0,1,0},{1,0,1,0,0},{1,1,1,0,0},{1,0,0,1,0},{1,0,0,0,1}},   // K
    {{0,1,0,0,0},{0,1,0,0,0},{0,1,0,0,0},{0,1,0,0,0},{0,1,0,0,0},{0,0,1,1,1}},   // L
    {{1,0,0,0,1},{1,1,0,1,1},{1,0,1,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1}},   // M
    {{1,1,0,0,1},{1,1,0,0,1},{1,0,1,0,1},{1,0,1,0,1},{1,0,0,1,1},{1,0,0,1,1}},   // N
    {{0,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // O
    {{1,1,1,1,0},{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,0},{1,0,0,0,0},{1,0,0,0,0}},   // P
    {{0,1,1,1,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,1},{0,0,0,0,1}},   // Q
    {{1,1,1,1,1},{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,0},{1,0,0,1,0},{1,0,0,0,1}},   // R
    {{0,1,1,1,1},{1,0,0,0,0},{0,1,1,1,0},{0,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // S
    {{1,1,1,1,1},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0}},   // T
    {{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,1,1,0}},   // U
    {{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{0,1,0,1,0},{0,1,0,1,0},{0,0,1,0,0}},   // V
    {{1,0,0,0,1},{1,0,0,0,1},{1,0,0,0,1},{1,0,1,0,1},{0,1,1,1,0},{0,1,0,1,0}},   // W
    {{1,0,0,0,1},{0,1,0,1,0},{0,0,1,0,0},{0,0,1,0,0},{0,1,0,1,0},{1,0,0,0,1}},   // X
    {{1,0,0,0,1},{1,0,0,0,1},{0,1,0,1,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0}},   // Y
    {{1,1,1,1,1},{0,0,0,0,1},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0},{1,1,1,1,1}},   // Z
    {{0,0,0,0,0},{0,0,0,0,1},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0},{1,0,0,0,0}},   // /
    {{0,0,0,0,0},{1,0,0,0,0},{0,1,0,0,0},{0,0,1,0,0},{0,0,0,1,0},{0,0,0,0,1}},   // backslash
    {{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0},{0,1,0,0,0},{0,0,1,0,0},{0,0,0,1,0}},   // (
    {{0,1,0,0,0},{0,0,1,0,0},{0,0,0,1,0},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0}},   // )
    {{0,0,1,0,0},{0,1,0,0,0},{0,1,0,0,0},{1,1,0,0,0},{0,1,0,0,0},{0,0,1,0,0}},   // {
    {{0,0,1,0,0},{0,0,0,1,0},{0,0,0,1,0},{0,0,0,1,1},{0,0,0,1,0},{0,0,1,0,0}},   // }
    {{0,0,1,1,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,1,0}},   // [
    {{0,1,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,1,1,0,0}},   // ]
    {{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}},   // space
    {{0,0,0,0,0},{0,0,0,0,1},{0,0,0,1,0},{0,0,1,0,0},{0,0,0,1,0},{0,0,0,0,1}},   // <
    {{0,0,0,0,0},{0,1,0,0,0},{0,0,1,0,0},{0,0,0,1,0},{0,0,1,0,0},{0,1,0,0,0}},   // >
    {{0,0,0,0,0},{0,0,0,0,0},{0,1,1,1,1},{0,0,0,0,0},{0,1,1,1,1},{0,0,0,0,0}},   // =
    {{0,0,0,0,0},{0,0,0,0,0},{0,1,0,0,0},{1,0,1,0,1},{0,0,0,1,0},{0,0,0,0,0}},   // ~
    {{0,0,1,1,0},{0,0,1,1,0},{0,0,1,1,0},{0,0,1,1,0},{0,0,0,0,0},{0,0,1,1,0}},   // !
    {{0,1,1,1,0},{1,0,0,0,1},{0,0,0,1,0},{0,0,1,0,0},{0,0,0,0,0},{0,0,1,0,0}},   // ?
    {{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{1,1,1,1,1},{0,0,0,0,0},{0,0,0,0,0}},   // -
    {{0,0,0,0,0},{0,0,1,0,0},{0,0,1,0,0},{1,1,1,1,1},{0,0,1,0,0},{0,0,1,0,0}},   // +
    {{0,0,1,0,0},{0,1,0,1,0},{1,0,0,0,1},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}},   // ^
    {{0,0,0,0,1},{1,1,0,1,0},{1,0,1,0,0},{0,1,0,0,1},{1,0,0,1,1},{0,0,0,0,0}},   // %
    {{0,1,1,1,0},{1,0,0,0,0},{0,1,0,0,1},{1,0,1,0,1},{1,0,0,1,0},{0,1,1,0,1}},   // &
    {{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{1,1,1,1,1}},   // _ underscore
    {{1,1,1,1,1},{1,0,0,0,1},{1,0,0,0,1},{1,1,1,1,1},{0,0,0,0,0},{0,0,0,0,0}},   // degree
    {{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}},   // ' quote
    {{0,0,1,1,0},{0,0,1,1,0},{0,0,1,1,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}},   // " double quote
    {{0,0,0,0,0},{0,1,0,1,0},{0,0,1,0,0},{1,1,1,1,1},{0,0,1,0,0},{0,1,0,1,0}},   // *
    {{0,0,0,0,0},{0,0,1,1,0},{0,0,1,1,0},{0,0,0,0,0},{0,0,1,1,0},{0,0,1,1,0}},   // :
    {{0,0,0,0,0},{0,1,1,0,0},{0,1,1,0,0},{0,0,0,0,0},{0,0,1,0,0},{0,1,0,0,0}},   // ;
    {{0,1,1,1,1},{1,0,1,0,0},{0,1,1,1,0},{0,0,1,0,1},{1,1,1,1,0},{0,0,1,0,0}},   // $
    {{0,1,1,1,1},{1,0,0,0,0},{1,1,1,1,1},{1,1,1,1,1},{1,0,0,0,0},{0,1,1,1,1}},   // €
    {{0,0,0,0,0},{0,1,0,1,0},{1,1,1,1,1},{0,1,0,1,0},{1,1,1,1,1},{0,1,0,1,0}},   // #
    {{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,1,1,0},{0,0,1,1,0}},   // .
    {{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,1,1,0},{0,0,1,1,0},{0,0,0,1,0}},   // ,
    {{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0},{0,0,1,0,0}},   // |
};

int gpio_row[]={
    18,                 // 1
    16,                 // 2
    17,                 // 3
    25,                 // 4
    26,                 // 5
    27,                 // 6
    19,                 // 7
    5};                 // 8

int gpio_col[]={
    12,                 // 1
    13,                 // 2
    6,                  // 3
    23,                 // 4
    22,                 // 5
    24,                 // 6
    20,                 // 7
    21};                // 8

#define MAX_BUF 200
#define BLINK_SPEED 200     // default = 50 * 5 = 2500ms = 2.5s

// holds attribute for the character: blink, underscore, direction etc.
int attribute[MAX_BUF]={0};

int blink_stat=0;           // current blink status:  ON or OFF
int blink_speed=0;          // how fast to blink (default is BLINK_SPEED)
int blink_delay=0;          // count down-timer for blink on/off time (set with blink_speed)
int blink_wait_cnt=0;       // 0= no blink pending, 1= blink in progress, 2 = waiting for full character on display.
int blink_block=0;          // >0 NO move of column/row allowed as blink is in progress
int set_under=0;            // set underscore to this character

char disp_buf[MAX_BUF]={0}; // holds the characters to display
int w_pnt=0;                // write pointer in disp_buf
int r_pnt=0;                // read pointer in disp_buf

int gpio_set=0;             // allow only 1 GPIO setup.
long  w_sleep;              // used by psleep()
struct termios oldterm;     // getch() support
int restore_getch;          // indicates that keyboard needs to be restored

int refresh_rate=10;        // default in mS.
int dis_bright=1150;        // default brightness (usec)
int c_col=0;                // current colum in character
int c_row=0;                // current colum in character
int c_d_row=5;              // current row in character moving down
int d_row=0;                // current column on display
int m_speed, mv_speed = 10; // speed of moving columns/rows on display
int repeat=0;               // 1 = repeat message

// indicates that source is being updated and is time critical
// do NOT refresh the display (display might glitch as a result!)
int capture_busy=0;

// number or supported characters
int len = sizeof(disp_char)/sizeof(disp_char[0]);

/* wait for the last characters to be displayed */
void wait_exit(int opt)
{
    while (r_pnt != w_pnt) psleep(refresh_rate * mv_speed);

    if (opt == 1 ){
        do_exit(1);
        exit(0);
    }
}

/*
 * programmed sleep (as normal sleep breaks with itimer())
 * provide the time is in 5ms increments
 * lowest refresh is 5ms  => 200Hz.
 * so if the value of :
 * 20 => 20 x 5 = 100mS
 * 100 => 100 x 5 = 500ms
 * 1000 => 500ms => 5 sec
 */

void psleep(long m_sec_wait)
{
    // #### to MEASURE AND DISPLAY wait time : #####
    // uncomment next 4 lines (also see at end of psleep)
    //struct timeval tv;
    //time_t  st,af;
    //gettimeofday(&tv,NULL);
    //st =  (tv.tv_sec*1000000) + tv.tv_usec;

    // adjust counter to keep 5ms in case of slower refresh-rate.
    w_sleep = (m_sec_wait * 5) / refresh_rate ;

    while (w_sleep > 0) usleep(50);

    // #### to MEASURE AND DISPLAY wait time : #####
    // uncomment next 3 lines (also see at begin of psleep)
    //gettimeofday(&tv,NULL);
    //af =  (tv.tv_sec*1000000) + tv.tv_usec;
    //printf("refresh_disp: %d\t  it took %d\n",af, (af - st));
}

/* set blinking ON or OFF
 * set parameter: on = (SET), off = (CLR)
 */
void set_blink(int set)
{
    if (set == SET)     attribute[w_pnt] |=  BLINK;
    else    attribute[w_pnt] &= ~BLINK;
}

/* set underscore ON or OFF
 * set parameter: on = (SET), off = (CLR)
 */
void set_underscore(int set)
{
    if (set == SET)     attribute[w_pnt] |= UNDER;
    else    attribute[w_pnt] &= ~UNDER;
}

/* set the blink speed : CLR = default  */
int set_blink_speed(int speed)
{
    // set speed or default speed
    // normalized in case refresh_rate was adjusted
    if (speed == CLR)
        blink_speed = (BLINK_SPEED * 5) / refresh_rate;

    else{
        if ((speed < 50) || (speed > 300)) return(1);

        blink_speed = (speed * 5) / refresh_rate;
    }

    if (debugg)
        printf ("blinking speed %d\n",blink_speed);
}

/* display message at start and end
 *  @dir :
 *  START = "Hello"
 *  CLR = "Bye"  */
void e_message(int dir)
{
    char buf1[]="Hello!";
    char buf2[]="Bye!";

    // clear any attribute
    set_blink(CLR);
    set_underscore(CLR);
    set_move_dir(LEFT);

    if (dir == START)    set_string(NEW, buf1);
    else set_string(NEW, buf2);

    wait_exit(0);
}

/* will perform exit.
 * parameter : flsh will display closing message*/

void do_exit(int flsh){
    int lp, row, col;

    // in case update was blocked
    capture_busy=0;

    // set GPIO's low
    for (col = 0; col < 8; col++){  // col

        for (row=0; row<8; row++){  // row

#ifdef _wiring
            digitalWrite(gpio_col[col],LOW);
            digitalWrite(gpio_row[row],LOW);
#else
            bcm2835_gpio_write(gpio_col[col],LOW);
            bcm2835_gpio_write(gpio_row[row],LOW);
#endif
        }
    }
    // display closing message
    if (flsh == CLR)  e_message(CLR);

    // clear refresh timer
    stop_timer();

    // short break for timer to stop
    usleep(dis_bright);

    // restore keyboard (if interrupted during get_ch())
    if (restore_getch)
    {
        if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){ // Restore the old settings.
            perror("tcsetattr() error ");
            puts("Attempting to recover old settings.");

            if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){
                perror("tcsetattr() error ");
                puts("Gave up...\nI suggest you restart your terminal -- old settings were not restored.");
            }
        }
    }
}

/* setup hardware and program in the right way */

void do_init(int sig)
{
    int lp,i;
    struct sigaction act;

#ifdef _wiring
    if (gpio_set == 0){     // setup for GPIO (ONCE !)
        wiringPiSetupGpio();
        gpio_set = 1;
    }
#else
        bcm2835_init();
#endif

    // clear input buffers
    clr_buffer(1);

    // set GPIO's to not display
    for (lp = 0; lp < 8; lp++){
#ifdef _wiring
        pinMode(gpio_col[lp],OUTPUT);
        pinMode(gpio_row[lp],OUTPUT);
        digitalWrite(gpio_col[lp],HIGH);
        digitalWrite(gpio_row[lp],LOW);
#else
        bcm2835_gpio_fsel(gpio_col[lp], BCM2835_GPIO_FSEL_OUTP);
        bcm2835_gpio_fsel(gpio_row[lp], BCM2835_GPIO_FSEL_OUTP);
        bcm2835_gpio_write(gpio_col[lp],HIGH);
        bcm2835_gpio_write(gpio_row[lp],LOW);
#endif
        for (i = 0; i < 8; i++) cur_dsp[lp][i]=0;
    }

    // set moving speed
    m_speed = mv_speed;

    // enable blink_delay
    set_blink_speed(0);

    // setup signals for cntrl-c (if requested)
    if (sig == CTRLC){
        memset(&act, '\0',sizeof(act));
        act.sa_handler = &signal_handler;
        sigemptyset(&act.sa_mask);

        sigaction(SIGTERM,&act, NULL);
        sigaction(SIGINT,&act, NULL);
        sigaction(SIGABRT,&act, NULL);
    }

    // set refreshtimer
    if (start_timer(refresh_rate, &refresh_disp))
    {
        printf("\ntimer error\n");
        do_exit(0);
        exit(1);
    }

    // set start message
    e_message(START);
}


/* perform a test on the display */
int do_selftest()
{
    int row, col, lp;
    char buf[]="0123456789";
    char buf1[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    char buf2[]="abcdefghijklmnopqrstuvwxyz";
    char buf3[]="(){}[]!~#$@%^&*-_=+\\|/?.,<>;:@";

    clr_buffer(1);

    // disable moving
    blink_block=1;

    // single dot
    printf(YLWSTR,"Self test : single dot\n");
    for (col=0;col < 8;col++){

        for (row=0;row < 8;row++){
            cur_dsp[row][col] = 1;
            psleep(10);
            cur_dsp[row][col] = 0;
        }
    }

    // single column
    printf(YLWSTR,"Self test : single column\n");
    for (col=0;col < 8;col++){

        for (row=0;row < 8;row++)
            cur_dsp[row][col] = 1;

        psleep(50);

        for (row=0;row < 8;row++)
            cur_dsp[row][col] = 0;
    }

    // single row
    printf(YLWSTR,"Self test : single row\n");
    for (row=0;row < 8;row++){
        for (col=0;col < 8;col++)
            cur_dsp[row][col] = 1;

        psleep(50);

        for (col=0;col < 8;col++)
            cur_dsp[row][col] = 0;
    }

    // moving cross
    printf(YLWSTR,"Self test : cross\n");
    for (lp=0; lp < 5;lp++)
    {
        for (row=0;row < 7;row++){
            cur_dsp[row][3] = 1;
            cur_dsp[3][row] = 1;
        }

        psleep(100);

        for (row = 0; row < 7; row++){

            for (col=0; col< 7; col++){
                if (col + row == 6) cur_dsp[row][col] = 1;
                else if (col - row == 0) cur_dsp[row][col] = 1;
                else cur_dsp[row][col] = 0;
            }
        }

        psleep(100);

        // clear every 2 rounds
        if (lp%2)
        {
            for (row = 0; row < 8; row++)
            {
                for (col=0; col<8; col++)
                    cur_dsp[row][col] = 0;
            }
        }
    }

    //clear
    for (row = 0; row < 8; row++){
        for (col=0; col<8; col++)
            cur_dsp[row][col] = 0;
    }

    //enable moving
    blink_block=0;

    printf(YLWSTR,"Self test : numeric characters\n");
    for(lp=0;lp<strlen(buf);lp++){
        set_char(APPEND,buf[lp]);
        printf("now on display : %c\n",buf[lp]);
        wait_exit(0);
    }

    printf(YLWSTR,"Self test : upper case characters\n");
    for(lp=0;lp<strlen(buf1);lp++){
        set_char(APPEND,buf1[lp]);
        printf("now on display : %c\n",buf1[lp]);
        wait_exit(0);
    }

    printf(YLWSTR,"Self test : lower case characters\n");
    for(lp=0;lp<strlen(buf2);lp++){
        set_char(APPEND,buf2[lp]);
        printf("now on display : %c\n",buf2[lp]);
        wait_exit(0);
    }

    printf(YLWSTR,"Self test : special characters\n");

    for(lp=0;lp<strlen(buf3);lp++){
        set_char(APPEND,buf3[lp]);
        printf("now on display : %c\n",buf3[lp]);
        wait_exit(0);
    }

    printf(YLWSTR,"Self test has finished\n");

    wait_exit(1);
}

/* update display content moving left */
void disp_update_left()
{
    int val, lp, row, col;

    // move dots to left on current display
    // unless waiting for blink to finish

    if (blink_block == 0){

        // delay counter (for shifting character column)
        if (m_speed-- > 0){
            to_disp();              // keep refresh going
            return;
        }
        else
            m_speed = mv_speed;

       for (col=0; col < 8; col++) {
            for (row = 0; row < 8; row++){
                if (col != 7)
                    cur_dsp[row][col] = cur_dsp[row][col+1];
                else
                    cur_dsp[row][col] = 0;
            }
        }
    }

    // end of previous character ?
    if (c_col == 5){

        // add a space column
        for(row = 0; row < 6;row++)
            cur_dsp[row][7] = 0;

        // set for next char
        c_col = 0;
        r_pnt++;

        // to enable blink: indicate character is on display
        if (blink_wait_cnt == 2)  blink_wait_cnt = 1;

        // add underscore?
        if (attribute[r_pnt] & UNDER){
            cur_dsp[7][7] = 1; // make continues
            set_under=1;
        }
        else  set_under=0;
    }
    // add next column UNLESS waiting for blink to finish
    else if (blink_block == 0)
    {

        val = disp_buf[r_pnt];

        // if not last in buffer
        if (val != 0){

            // get character offset
            for (lp = 0; lp < len; lp++){

                if (disp_char[lp] == val) break;
            }

            // match found
            if (lp != len)
            {
                // set each row in current column
                for(row = 0; row < 6; row++){
                       cur_dsp[row][7] = disp_char_r_c[lp][row][c_col];
                }

                // add underscore ?
                if (set_under == 1 ) cur_dsp[7][7]=1;

                c_col++;
            }
        }
        else
        {
            if (repeat){
                // reset pointers to start
                w_pnt = 0;
                r_pnt = 0;
            }
            else
            {
                // reset pointers if end of buffer
                clr_buffer(0);
            }
        }
    }
    // do the display refresh
    to_disp();

}

/* update display content moving up */

void disp_update_up()
{
    int val, lp, row, col;

    // move dots up on current display
    // unless waiting for blink to finish

    if (blink_block == 0){

        // delay counter (for shifting character row)
        if (m_speed-- > 0){
            to_disp();              // keep refresh going
            return;
        }
        else
            m_speed = mv_speed;

       for (col=0; col < 8; col++) {
            for (row = 0; row < 8; row++){
                if (row != 7)
                    cur_dsp[row][col] = cur_dsp[row+1][col];
                else
                    cur_dsp[row][col] = 0;
            }
        }
    }

    // end of previous character ?
    if (c_row == 6) {

        // add a space row
        for(col = 0; col < 5;col++)
            cur_dsp[7][col] = 0;

        // set for next char
        c_row = 0;
        r_pnt++;

        // to enable blink: indicate character is on display
        if (blink_wait_cnt == 2)  blink_wait_cnt = 1;

        // add underscore?
        if (attribute[r_pnt] & UNDER){

            if (set_under == 0)
                set_under = 1;   // move up one line next refresh
        }
    }
    // adding underscore in progress ?
    else if (set_under > 0) {

         if (set_under == 1){   // add underscore

            for(col = 1; col < 6;col++)
                cur_dsp[7][col] = 1;

            set_under = 2;      // move up one line next refresh
         }
         else
            set_under = 0;      // done with underscore
    }

    // add next column UNLESS waiting for blink to finish
    else if (blink_block == 0)
    {
        val = disp_buf[r_pnt];

        // if not last in buffer
        if (val != 0){

            // get character offset
            for (lp = 0; lp < len; lp++){

                if (disp_char[lp] == val) break;
            }

            // match found
            if (lp != len)
            {
                // set each row in current column
                for(col = 0; col < 5; col++){
                       cur_dsp[7][col+1] = disp_char_r_c[lp][c_row][col];
                }

                c_row++;
            }
        }
        else
        {
            if(repeat){
                // reset pointers to start
                w_pnt = 0;
                r_pnt = 0;
            }
            else
            {
                // reset pointers if end of buffer
                clr_buffer(0);
            }
        }
    }
    // do the display refresh
    to_disp();

}

/* update display content moving up */

void disp_update_down()
{
    int val, lp, row, col;

    // move dots down on current display
    // unless waiting for blink to finish

    if (blink_block == 0){

        // delay counter (for shifting character row)
        if (m_speed-- > 0){
            to_disp();              // keep refresh going
            return;
        }
        else
            m_speed = mv_speed;

       for (col=0; col < 8; col++) {
            for (row = 7; row > -1; row--){
                if (row != 0)
                    cur_dsp[row][col] = cur_dsp[row-1][col];
                else
                    cur_dsp[row][col] = 0;
            }
        }
    }

    // end of previous character ?
    if (c_d_row == -1) {

        // add a space row
        for(col = 0; col < 5;col++)
            cur_dsp[0][col] = 0;

        // set for next char
        c_d_row = 5;
        r_pnt++;

        // to enable blink: indicate character is on display
        if (blink_wait_cnt == 2)  blink_wait_cnt = 1;

        // add underscore?
        if (attribute[r_pnt] & UNDER){

            if ((set_under == 0) && (disp_buf[r_pnt] != 0 ))
                set_under = 1;   // move up one line next refresh
        }
    }
    // adding underscore in progress ?
    else if (set_under > 0) {

         if (set_under == 1){   // add underscore

            for(col = 1; col < 6;col++)
                cur_dsp[0][col] = 1;

            set_under = 2;      // move up one line next refresh
         }
         else
            set_under = 0;      // done with underscore
    }

    // add next column UNLESS waiting for blink to finish
    else if (blink_block == 0)
    {

        val = disp_buf[r_pnt];

        // if not last in buffer
        if (val != 0){

            // get character offset
            for (lp = 0; lp < len; lp++){

                if (disp_char[lp] == val) break;
            }

            // match found
            if (lp != len)
            {
                // set each row in current column
                for(col = 0; col < 5; col++){
                       cur_dsp[0][col+1] = disp_char_r_c[lp][c_d_row][col];
                }

                c_d_row--;
            }
        }
        else
        {
            if (repeat){
                // reset pointers to start
                w_pnt = 0;
                r_pnt = 0;
            }
            else
            {
                // reset pointers if end of buffer
                clr_buffer(0);
            }
        }
    }
    // do the display refresh
    to_disp();

}
/* refresh the display */
void to_disp()
{
    int row, col,ref=0;

    // blink set for this character wait for the character on display
    if (attribute[r_pnt] & BLINK){
        if (blink_wait_cnt == 0)  blink_wait_cnt = 2;
    }

    // is the character on the display for blink (disp_update)
    if (blink_wait_cnt == 1 )
    {
        // set how long to wait for character to blink (if not set already)
        if (blink_block == 0)   blink_block = blink_speed * 5;

        // still holding character for blink
        else if (blink_block > 1)
        {
            blink_block--;              // decrement wait time
                                        // blink with blink_speed frequency
            if (blink_stat == 0)        // is set to off?
            {
                if (blink_delay-- > 0)  // timer expired?
                    return;
                                        // reset speed
                blink_delay = blink_speed;
                blink_stat = 1;         // set as on
            }
            else
            {
                if (blink_delay-- <= 0) // timer expired?
                {
                                        // reset speed
                    blink_delay = blink_speed;
                    blink_stat = 0;     // set as off
                    return;
                }
            }
          }
          else     // reset blink as this character is finished
          {
            blink_block=0;              // enable move column/row
            blink_wait_cnt=0;           // blink is done
            blink_stat=0;               // blink is off
            blink_delay = blink_speed;  // reset blink delay
          }
    }

    // refresh the display
    // blink_stat is used to prevent column 0 & 8 to be part of blinking
    for (col = blink_stat; col < (8-blink_stat); col++){

#ifdef _wiring
        digitalWrite(gpio_col[col],LOW);
#else
        bcm2835_gpio_write(gpio_col[col],LOW);
#endif
        for (row = 0; row < 8; row++)
        {
            if (cur_dsp[row][col] == 1)
            {
               ref=1;
#ifdef _wiring
                digitalWrite(gpio_row[row],HIGH);
#else
                bcm2835_gpio_write(gpio_row[row],HIGH);
#endif
            }
         }
        // anything on this column ?
        if (ref)
        {
            ref=0;
            // the longer the sleep the brighter the display
            usleep(dis_bright);

            // de-select row/column
            for (row = 0; row < 8; row++)
            {
                // de-select led that was set
                if (cur_dsp[row][col] == 1)
                {
#ifdef _wiring
                    digitalWrite(gpio_row[row],LOW);
#else
                    bcm2835_gpio_write(gpio_row[row],LOW);
#endif
                }
            }
        }
        // deselect column
#ifdef _wiring
        digitalWrite(gpio_col[col],HIGH);
#else
        bcm2835_gpio_write(gpio_col[col],HIGH);
#endif

    }
}

/*
 * set move speed in increments of 5ms
 * max is 5 = 25ms
 * min is 60 = 300ms
 */
int set_move_sp(int speed)
{

    if ((speed > 60) || (speed < 5))
        return(1);

    else
        mv_speed = (speed * 5) / refresh_rate ;

    return(0);
}

/*
 * set move direction
 */
int set_move_dir(int direct)
{
    if (direct == LEFT)     attribute[w_pnt] |= MLEFT;
    else if (direct == UP)  attribute[w_pnt] |= MUP;
    else if (direct == DOWN)attribute[w_pnt] |= MDOWN;
    else
        return(1);

    return(0);

}
/* sets a character
 * instr:
 * APPEND = add to current buffer
 * START = add at beginning
 * NEW = clear current buffer  */

int set_char (int instr, char val){

    int lp;

    // check character is supported
    for (lp = 0; lp < len; lp++){
        if (disp_char[lp] == val)   break;
    }

    // if not supported
    if (lp == len)  {
        if (debugg) printf("unsupported character %c %x\n", val, val);
        return(1);
    }

    if (instr == NEW)
    {
        clr_buffer(0);
        disp_buf[w_pnt++] = val;
        disp_buf[w_pnt]=0;
    }
    else if (instr == START)
    {
        if (w_pnt < MAX_BUF-2){
            // move up in buffer
            for (lp = w_pnt; lp > -1 ; lp--){
                disp_buf[lp+1] = disp_buf[lp];
                attribute[lp+1] = attribute[lp];
            }

            disp_buf[0] = val;
            w_pnt++;
            disp_buf[w_pnt] = 0;
        }
        else
        {
            printf("Input buffer exceeded\n");
            return(1);
        }
    }
    else if (instr == APPEND)
    {
        if (w_pnt < MAX_BUF-2){

            // copy current attributes
            attribute[w_pnt+1] = attribute[w_pnt];

            disp_buf[w_pnt++]= val;

            disp_buf[w_pnt] = 0;
        }
        else{
            printf("Input buffer exceeded\n");
            return(1);
        }
    }
    else
        return(1);

    return(0);
}

/* clears the message buffer
 * optional clear the display as well
 */

void clr_buffer(int clr)
{
    int row, col;

    w_pnt = 0;          // write pointer
    disp_buf[w_pnt]=0;  // so buffer zero
    r_pnt = 0;          // read pointer

    // clear any attribute
    for (row = 0; row < MAX_BUF; row++)
        attribute[row]=CLR;

    blink_wait_cnt = 0; // no pending blink
    blink_block = 0;    // enable moving column/row

    if (clr){
        // clear display
        for (row = 0; row < 8; row++){

            for (col=0; col<8; col++)
                cur_dsp[row][col] = 0;
        }
        c_col = 0;          // reset character column
        c_d_row = 5;        // reset character row down
    }
}

/* sets to display a buffer
 * instr:
 * APPEND = add to current buffer
 * START = add at beginning
 * NEW = clear current buffer  */

int set_string(int instr, char buf[])
{
    int lp = 0;

    if (instr == NEW)
    {
        clr_buffer(0);

        for(lp = 0; lp < strlen(buf); lp++){

            if (set_char(APPEND,buf[lp])){
                if (debugg) printf("Error during setting character in new buffer\n");
                return(1);
             }
        }
    }
    else if (instr == START)
    {

        for(lp = strlen(buf); lp >-1; lp--){

            if (set_char(START,buf[lp])){
                if (debugg) printf("Error during setting character at start buffer\n");
                return(1);
             }
        }
    }
    else if (instr == APPEND)
    {
        for(lp = 0; lp < strlen(buf); lp++){

            if (set_char(APPEND,buf[lp])){
                if (debugg) printf("error during appending character to buffer\n");
                return(1);
            }
        }
    }
    else
        return(1);

    if (debugg) printf("now in buffer %s\n",disp_buf);

    return(0);
}

/* adds value to string (max 20 characters)
 * instr:
 * APPEND = add to current buffer
 * START = add at beginning
 * NEW = clear current buffer  */
int set_value (int instr, int num){

    int lp = 0, dd, len = 1;
    char buff[21];

    dd = num;

    //determine # charaters (max is 20)
    while(dd > 9){
        dd = dd / 10;
        len++;
    }

    if (len > 20) return(1);

    sprintf(buff,"%d\0",num);

    // only if NEW was requested
    if (instr == NEW){
        clr_buffer(0);
        instr=APPEND;
    }

    for(lp = 0; lp < strlen(buff); lp++){

        if (set_char(instr,buff[lp]))
            return(1);
    }

    return(0);
}

/* update refresh time. value in ms */
int set_refresh( int rate){
    if ((rate < 5) || (rate > 25)) return(1);

    /* refresh time is max 8 x dis_bright.
     * on brightlevel
     * 2000 microseconds x 8 = 16ms < 17ms refresh
     * 1300 microseconds x 8 = 10,1ms < 15ms refresh
     * 1150 microseconds x 8 = 9ms => 10ms refresh
     * 1000 microseconds x 8 = 8ms =>  9ms.
     * 900 microseconds x 8 = 7,2ms =>  8ms.
     * 800 microseconds x 8 = 6,4ms =>  7ms.
     * 650 microseconds x 8 = 5.2ms =>  6ms.
     * 500 microseconds x 8 = 4ms =>  5ms.
     */

    // this is adjusted (if needed) to prevent interrupt refresh.

    if (rate == 5)      {if (dis_bright > 500) dis_bright = 500;}
    else if (rate == 6) {if (dis_bright > 650) dis_bright = 650;}
    else if (rate == 7) {if (dis_bright > 800) dis_bright = 800;}
    else if (rate == 8) {if (dis_bright > 900) dis_bright = 900;}
    else if (rate == 9) {if (dis_bright > 1000) dis_bright = 1000;}
    else if (rate == 10){if (dis_bright > 1150) dis_bright = 1150;}
    else if (rate <= 15){if (dis_bright > 1300) dis_bright = 1300;}
    else if (rate == 16) {if (dis_bright > 1800) dis_bright = 1800;}

    refresh_rate = rate;
    return(update_timer(rate));

    if (debugg)
        printf ("refresh-rate %d, brightness %d\n",refresh_rate,dis_bright);

}

/* adjust brightness time. value in usec */
int set_brightness(int bright){

    if ((bright < 5) || (bright > 2000)) return(1);

    /* refresh time is max 8 x dis_bright + 400 micro for code
     * on brightlevel
     * 2000 microseconds x 8 = 16ms < 17ms refresh
     * 1300 microseconds x 8 = 10,1ms < 15ms refresh
     * 1150 microseconds x 8 = 9ms => 10ms refresh
     * 1000 microseconds x 8 = 8ms =>  9ms.
     * 900 microseconds x 8 = 7,2ms =>  8ms.
     * 800 microseconds x 8 = 6,4ms =>  7ms.
     * 650 microseconds x 8 = 5.2ms =>  6ms.
     * 500 microseconds x 8 = 4ms =>  5ms.
     *
     */

    if (refresh_rate == 5){if (bright > 500)  return(1);}
    else if (refresh_rate == 6) {if (bright > 650)  return(1);}
    else if (refresh_rate == 7) {if (bright > 800)  return(1);}
    else if (refresh_rate == 8) {if (bright > 900)  return(1);}
    else if (refresh_rate == 9) {if (bright > 1000)  return(1);}
    else if (refresh_rate == 10){if (bright > 1150)  return(1);}
    else if (refresh_rate < 15) {if (bright > 1300)  return(1);}
    else if (refresh_rate == 16){if (bright > 1800)  return(1);}

    dis_bright = bright;

    if (debugg)
        printf ("refresh-rate %d, brightness %d\n",refresh_rate,dis_bright);

    return(0);

}
/* repeat message
 * SET = keep repeating
 * CLR = do NOT repeat
 * default is do NOT repeat
 */
void set_repeat(int set)
{
    if (set == SET)     repeat=1;
    else    repeat=0;
}

/* called as itimer expires */
void refresh_disp(void)
{
    // to MEASURE AND DISPLAY refresh time :
    // uncomment next 4 lines (also see at end of refresh_dip)
    //struct timeval tv;
    //time_t  st,af;
    //gettimeofday(&tv,NULL);
    //st =  (tv.tv_sec*1000000) + tv.tv_usec;

    // count-down psleep
    if (w_sleep > 0)  w_sleep--;

    // return if capture of time critical data is busy
    if (capture_busy) return;

    // attribute to move up ?
    if (attribute[r_pnt] & MUP) disp_update_up();

    // attribute set to move down?
    else if (attribute[r_pnt] & MDOWN) disp_update_down();

    // else move left (default)
    else disp_update_left();

    // to MEASURE AND DISPLAY refresh time :
    // uncomment next 3 lines (also see at begin of refresh_dip)
    //gettimeofday(&tv,NULL);
    //af =  (tv.tv_sec*1000000) + tv.tv_usec;
    //printf("refresh %d\n",(af - st));
}

 /* Reads up to max characters into buffer.
  * Skips interrupted getchar() call by the itimer
  * Returns number of characters in buffer (terminated with \0)
  */
int get_line(char buf[], int max)
{   int len=0;
    char c;

    while(len < max){
        while ((c=getchar()) == 0xff);    // loop to get value character
        if (c == '\n') break;
        buf[len++]=c;
    }

    buf[len]='\0';
    return(len);
}

/* getch(), gets a single character at a time without a return nor display.
 * returns read character if successful.
 * returns -1 on non-fatal error.
 * returns -2 on fatal error.
 */
char get_ch()
{
    struct termios newterm;
    char    buf;

    if(tcgetattr(STDIN_FILENO, &newterm) < 0)
    {
          // Get the old settings to modify
          perror("tcgetattr() error ");
          return -1;
    }

    oldterm = newterm;
    newterm.c_lflag    &= ~(ECHO | ICANON);               // Turn off echo and canonical mode (this is what makes it not wait for a newline)
    newterm.c_cc[VMIN]  = 1;                              // Set the amount of characters to get to 1
    newterm.c_cc[VTIME] = 0;                              // No timeout on waiting for the character
    if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &newterm) < 0){ // Flush the buffer (TCSAFLUSH), then set the new terminal settings.
           perror("tcsetattr() error ");
           return -1;
    }

    restore_getch = 1;

    buf = 0xff;
    while( buf == 0xff)
        buf = fgetc(stdin);                              // Here is the getc() you've been waiting for!


    if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){ // Restore the old settings.
        ///perror("tcsetattr() error ");
        //puts("Attempting to recover old settings.");

        if(tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldterm) < 0){
            //perror("tcsetattr() error ");
            //puts("Gave up...\nI suggest you restart your terminal -- old settings were not restored.");
            return -2;
        }
    }

    restore_getch = 0;

    return buf;
}


/*
 * read character from keyboard
 * Skips interrupted getch() call by the itimer
 */
char get_char()
{
    char c;

    while (1){
       c=getchar();

       if (c != 0xff)    // loop to get value character
            return(c);
    }
}

void signal_handler(int sig_num)
{
    switch(sig_num)
    {

    case SIGABRT:
    case SIGINT:
    case SIGTERM:
        printf(GRNSTR,"\nsignal interrupt : stopping display\n");
        do_exit(CLR);
        exit(0);
        break;

    }
}
