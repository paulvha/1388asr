/*
 * examples to  display on 1388ASR
 *
 * version 1.0 / paulvha / april 2016
 *
 * see 1388asr.h for details
 *
 *
 * ***************************************************************************
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 ***************************************************************************
 *
 * This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 *
 ***************************************************************************
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "1388asr.h"


/* set the numeric value to display */
int get_value()
{
    int lp, num1=0, invalid, len;
    long num=0xff;
    char ch;
    char buf[21]={0};

    printf(REDSTR,"Welcome to get_value\n");

    while(1){

        invalid = 0;
        num = 0xff;

        printf(YLWSTR,"Enter a numeric value of max 20 digits. (! = exit) ");

        while (num == 0xff){

            // clear input buffer
            for (lp = 0; lp < 21 ;lp++) buf[lp]=0x0;

            // get input
            if (get_line(buf,20)) {

                // empty entry ?
                if (buf[0] == 0x0) continue;

                //check if valid number
                for (lp = 0; lp < 20 ;lp++){

                    // exit requested?
                    if (buf[lp] == '!'){
                        printf(REDSTR,"exiting get_value\n");
                        return;
                    }

                    // end of buffer?
                    else if (buf[lp] == 0x0){
                        num = atol(buf);
                        printf ("Now on display : %d\n",num);
                        set_value(NEW,num);

                        // wait for all displayed
                        wait_exit(0);
                        break;
                    }

                    // check on numeric value
                    num1 = (int) buf[lp] - '0';
                    if ((num1 < 0) || (num1 > 9)){
                        printf ("Invalid number %c\n",buf[lp]);
                        break;
                    }
                }
            }
            else
            {
                printf("to many characters in input\n");
            }
        }
    }
}

/* display a pre-initialised string */
void test_string()
{
    //char val1[]="....THIS IS A TEST STRING - 0123456789 - BY SEE YOU !! ";
    char val1[]="L";

    printf(REDSTR,"Welcome to test_line\n");
    set_char(NEW,'A');
    set_char(APPEND,'B');

    set_blink(SET);
    set_char(APPEND,'C');
    set_char(APPEND,'D');
    set_char(APPEND,'E');
    set_blink(CLR);

    set_underscore(SET);
    set_char(APPEND,'F');
    set_char(APPEND,'G');
    set_char(APPEND,'H');

    set_underscore(CLR);
    set_blink(CLR);

    set_move_sp(30);
    set_move_dir(DOWN);

    set_char(APPEND,'I');
    set_underscore(SET);
    set_char(APPEND,'j');
    set_move_dir(UP);
    set_char(APPEND,'K');
    set_underscore(CLR);
    set_char(APPEND,'L');
    set_char(APPEND,'m');
    set_move_dir(UP);

    wait_exit(0);

    printf("wait for enter\n");
    get_char();
}

/* get your input and display that is display on moving display*/
void test_line()
{
    char buf[40];
    char ch;
    int len;

    printf(REDSTR,"Welcome to test_line\n");

    while(1){
        printf("Enter a line (max. 40 characters) exit = enter\n");
        len = get_line(buf, sizeof(buf));
        if (len == 0) break;
        set_string(NEW, buf);

        /* wait for all displayed */
        wait_exit(0);
    }

    printf("done\n");
}

int main(int argc, char *argv[]) {

#ifdef _wiring
    // otherwise wiringPi will not work
    if (geteuid() != 0){
        printf("Must be run as root when use wiringPi library.\n");
        exit(-1);
    }
    printf("using wiringPi library\n");
#else
    printf("using BCM2835 library\n");
#endif


    /* initialise and set control-c on.*/
    // MUST ALWAYS BE DONE FIRST !!
    do_init(CTRLC);

    /*** INSTRUCTIONS : ***
     * remove // before the ROUTINES that you want to test
     */

    /* Set brightness higher, to be combined with other routines */
    //set_brightness(1500);

    /*keep repeating message in buffer, to be combined with other routines*/
    // set_repeat(SET);

    /* do a self_test */
    //do_selftest();

    /* show pre-created string */
    // test_string();

    /* get keyboard line input and display on move display*/
    test_line();

    /* get a number value and display */
    //get_value();

    /* ALWAYS PERFORM do_exit at the end */
    do_exit(1);

}
